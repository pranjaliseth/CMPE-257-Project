This is an example project to build academic papers using markdown and pandoc.

## Install

First you need to install [Pandoc](https://pandoc.org/installing.html)

Next, install some Python packages:

	pip install -r requirements.txt

Finally, it is not necessary but installing the entr tool makes it so your pdf gets generated every time your markdown files change.


## Run

Modify paper.md then in a terminal window run either make or run.sh (auto build)

