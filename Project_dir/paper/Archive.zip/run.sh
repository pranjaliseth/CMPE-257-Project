ls *.md | entr sh -c make
